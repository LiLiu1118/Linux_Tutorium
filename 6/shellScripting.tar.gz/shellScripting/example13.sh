#!/bin/bash
 
A=2
echo $((++A))
echo $A
let "A = 50 % 6"
echo ${A+5}
echo $(date | rev)
read -p "Whats your age? "
echo $REPLY
export A=2; echo $A; (echo $((++A)); echo $A); echo $A


#!/bin/bash
 
echo "Whats your favorite color?"
select MYSEL in red green blue; do
  echo $MYSEL;
  break;
done
exit 0


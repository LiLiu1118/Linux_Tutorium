#!/bin/bash
 
case $1 in
  1)
    echo "you entered 1" 
    ;;
  hello)
	  echo "Hello $(getent passwd | grep $USER | cut -f 5 -d ':' | tr -d ',')"
    ;;
  *)
    echo "unknown argument $1"
    ;;
esac
exit 0


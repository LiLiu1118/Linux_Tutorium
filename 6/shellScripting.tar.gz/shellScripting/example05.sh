#!/bin/bash

TESTFILE=example05.dat
if [ -f $TESTFILE ]; then 
  rm $TESTFILE; 
fi

touch $TESTFILE

for MYVAR in $@; do
  echo $MYVAR >> $TESTFILE
done

while read MYVAR; do
  echo $MYVAR
done < $TESTFILE

for MYVAR in {1..5}; do
  echo $MYVAR
done

exit 0

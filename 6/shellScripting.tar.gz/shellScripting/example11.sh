#!/bin/bash

# better:

head -n1 $( \
  for FILE in $(ls); do \
	if [ -f $FILE ]; then \
	  echo $FILE;
	fi;
  done )
exit 0

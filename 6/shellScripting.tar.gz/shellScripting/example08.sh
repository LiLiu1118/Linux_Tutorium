#!/bin/bash

while getopts "abc:def:ghi" flag; do
  echo "$flag $OPTIND $OPTARG"
done

#!/bin/bash

COUNTER=0
until [ $COUNTER -gt 3 ]; do
  echo $((COUNTER++))
done
exit 0

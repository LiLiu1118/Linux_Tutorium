#!/bin/bash

trap '' 9
trap '' 2
trap '' 15
echo "$FUNCNAME"
echo "Goodbye world!"
#kill $BASHPID
kill $$
echo "Oh noes!"

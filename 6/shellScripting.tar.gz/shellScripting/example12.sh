#!/bin/bash

function calculate {
  echo "scale=4; $1" | bc
}

RESULT=$(calculate 2*2)
RESULT=$(calculate $RESULT/12)
echo "RESULT = $RESULT"

exit 0

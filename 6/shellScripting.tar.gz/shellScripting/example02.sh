#!/bin/bash

LOCALVAR="hallo welt"

echo "LOCALVAR = $LOCALVAR"

echo "GLOBALVAR = $GLOBALVAR"

echo "FIRST ARGUMENT = $1"

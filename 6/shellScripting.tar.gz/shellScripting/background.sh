#!/bin/bash
set -x
(sleep 1 && echo Hallo) & (sleep 2 && echo Welt) & wait

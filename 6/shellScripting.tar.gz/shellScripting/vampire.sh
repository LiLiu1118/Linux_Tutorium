#!/bin/bash

trap 'echo "(vamp) You cannot kill me!"' 15

echo "(climbing out of coffin)"

read -p "(vamp) Let me taste some blood..." ARG


#!/bin/bash

# old way:

for FILE in `ls`; do
  echo $FILE
done
exit 0

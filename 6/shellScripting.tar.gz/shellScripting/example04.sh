#!/bin/bash

case $1 in
  1)
	echo "you entered 1"
	;;
  h[ae]llo)
	echo "hello world"
	;;
  '')
	echo "no argument"
	;;
#  *)
#	echo "unknown argument '$1'"
#	;;
esac
echo "hello World"

#!/bin/bash

# this is a comment

# lets give some feedback...

echo "hello world"

# and return
exit 0

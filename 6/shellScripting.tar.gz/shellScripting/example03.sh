#!/bin/bash

if [ "$1" == '$1' ]; then
  echo "argument 1: $1"
  echo "argument 2: $2"
else
  echo "no arguments"
fi

#!/bin/bash
#/* 
#
#     _______.___________. _______     _______.
#    /       |           ||   ____|   /       |
#   |   (----`---|  |----`|  |__     |   (----`
#    \   \       |  |     |   __|     \   \
#.----)   |      |  |     |  |    .----)   |
#|_______/       |__|     |__|    |_______/
#
#All rights reserved!
#Contact the authors for more information
#
#Date:Mo 25 Nov 2019 22:36:22 CET
# 
#
#Author:Philip Haspel, M.Sc.
# 
#
#Email:haspel@stfs.tu-darmstadt.de
#*/ 
if ! docker image ls | grep -irn imagetutorium; then
    docker build -t imagetutorium .
    docker run -it --name linuxtutorium imagetutorium /bin/bash
else
    if  ! docker ps -a  | grep -irn linuxtutorium; then
        echo "Image already there, just the container is run"
        docker run -it --name linuxtutorium imagetutorium /bin/bash
        exit 0;
    else
        if ! docker container ls | grep -irn linuxtutorium; then
            docker start -a linuxtutorium
            exit 0;
        else
            docker attach linuxtutorium
        fi
    fi
fi

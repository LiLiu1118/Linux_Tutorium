#!/bin/bash

function pause()
{
  echo ""
  read -p "Enter to continue"
  echo ""
}

clear
echo -e "Third example for grep:\n"

file="namelist.txt"

echo -e "content of the file $file:\n"
cat $file
pause

echo -e "grep 'e[a]' $file \n"
grep 'e[a]' $file

echo -e "\ngrep 'e[^a]' $file \n"
grep 'e[^a]' $file

pause

file="pricelist.txt"

clear
echo -e "content of the file $file:\n"
cat $file
pause

echo -e "grep '[1-9]\$' $file \n"
grep '[1-9]$' $file
pause

echo -e "\ngrep '[1-9]\\\$' $file \n"
grep '[1-9]\$' $file
pause

echo -e "\ngrep '[0-9]\\\$' $file \n"
grep '[0-9]\$' $file
pause

echo -e "\ngrep '[:numbers:]\\\$' $file \n"
grep '[0-9]\$' $file
pause

file="installfiles.txt"

clear
echo -e "content of the file $file:\n"
cat $file
pause

echo -e "grep 'install*file' $file \n"
grep 'install*file' $file
pause

echo -e "grep 'install.*file' $file \n"
grep 'install.*file' $file
pause

echo -e "\ngrep 'install\\.*file' $file \n"
grep 'install\.*file' $file
pause

echo -e "\ngrep 'install.*\\.file' $file \n"
grep 'install.*\.file' $file

pause
file="numbers.txt"

clear
echo -e "content of the file $file:\n"
cat $file
pause

echo -e "grep '150\\?\>' $file \n"
grep '150\?\>' $file
pause

echo -e "grep '150*\>' $file \n"
grep '150*\>' $file
pause

echo -e "grep '150\\+\>' $file \n"
grep '150\+\>' $file
pause

echo -e "grep '150\\{2\\}' $file \n"
grep '150\{2\}' $file
pause

echo -e "grep '150\\{2\\}\>' $file \n"
grep '150\{2\}\>' $file
pause

echo -e "grep '150\\{2,\\}\>' $file \n"
grep '150\{2,\}\>' $file
pause

echo -e "grep '150\\{1,2\\}\>' $file \n"
grep '150\{1,2\}\>' $file
pause

echo -e "grep '\<150\\{1,2\\}\>' $file \n"
grep '\<150\{1,2\}\>' $file
pause

echo -e "grep '\<\\(150\\)\\{1,2\\}\>' $file \n"
grep '\<\(150\)\{1,2\}\>' $file
pause

echo -e "grep '\(2\)\(150\)\1\>' $file \n"
grep '\(2\)\(150\)\1\>' $file
pause

echo -e "grep '\(2\)\(150\)\2\>' $file \n"
grep '\(2\)\(150\)\2\>' $file
pause

echo -e "grep '\(2\)\|\(150\)\2\>' $file \n"
grep '\(2\)\|\(150\)\2\>' $file
pause

echo -e "grep '\(2\)\|\(150\)\1\>' $file \n"
grep '\(2\)\|\(150\)\1\>' $file
pause

echo -e "egrep '(2)|(150)\2\>' $file \n"
egrep '(2)|(150)\2\>' $file






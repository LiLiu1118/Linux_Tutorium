#!/bin/bash

function pause()
{
  echo ""
  read -p "Enter to continue"
  echo ""
}

clear
echo -e "Second example for grep:\n"

for file in "text1.txt" "text2.txt"  "text3.txt" 
do
    echo -e "content of the file $file:"
    cat $file
    pause
done

echo -e "grep dummy *.txt \n"
grep dummy *.txt

pause
 
echo -e "grep some *.txt \n"
grep some *.txt



#!/bin/bash

function pause()
{
  echo ""
  read -p "Enter to continue"
  echo ""
}

file=fruitlist.txt

clear
echo -e "First example for grep:\n"

echo -e "content of the file $file:"
cat $file

for tmp in "apple" "mandarine" "MelOn" 
do

  pause
  
  echo -e "grep $tmp $file\n"
  grep $tmp $file

done

pause

echo -e "grep -i MelOn $file\n"
grep -i MelOn $file

pause
 
echo -e "grep -v apple $file\n"
grep -v apple $file

pause
 
echo -e "grep -n apple $file\n"
grep -n apple $file

pause
 
echo -e "grep -c apple $file\n"
grep -c apple $file



#!/bin/bash

function pause()
{
  echo ""
  read -p "Enter to continue"
  echo ""
}

clear
echo -e "Third example for find:\n"

for file in "text1.txt" "text2.txt"  "text3.txt" 
do
    echo -e "content of the file $file:"
    cat $file
    echo ""
done

pause

echo -e "find . -name \"*.txt\" -exec grep \"dummy\" '{}' \;\n"
find . -name "*.txt" -exec grep "dummy" '{}' \; 

pause

echo -e "find . -name \"*.txt\" -exec grep \"dummy\" '{}' \; -print \n"
find . -name "*.txt" -exec grep "dummy" '{}' \; -print 

pause

echo -e "find . -name \"*.txt\" -exec grep \"some\" '{}' \; -print \n"
find . -name "*.txt" -exec grep "some" '{}' \; -print 

pause

echo -e "find -name \"*.txt\" | grep \"dummy\"\n"
find -name "*.txt" | grep "dummy"

pause

echo -e "find -name \"*.txt\" | grep \"text\"\n"
find -name "*.txt" | grep "text"

pause
echo -e "find -name \"*.txt\" | xargs grep \"dummy\"\n"
find -name "*.txt" | xargs grep "dummy"


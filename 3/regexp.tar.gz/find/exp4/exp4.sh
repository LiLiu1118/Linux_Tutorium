#!/bin/bash

function pause()
{
  echo ""
  read -p "Enter to continue"
  echo ""
}

clear
echo -e "Fourth example for find:\n"
echo -e "Files in this directory:\n"
ls *
pause

echo -e "find . -name 'a*'"
gfind . -name 'a*'
echo -e "\nfind . -regextype grep -regex 'a.*'"
gfind . -regextype grep -regex 'a*'
pause

echo -e "\nfind . -regextype grep -regex './a.*'"
gfind . -regextype grep -regex './a.*'
pause

echo -e "\nfind . -regextype grep -regex './aa\?\.txt'"
gfind . -regextype grep -regex './aa\?\.txt'

pause
echo -e "\nfind . -regextype grep -regex './a\{1,2\}\.txt'"
gfind . -regextype grep -regex './a\{1,2\}\.txt'







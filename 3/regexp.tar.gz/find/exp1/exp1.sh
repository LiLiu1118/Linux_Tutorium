#/bin/bash

function pause()
{
  echo ""
  read -p "Enter to continue"
  echo ""
}

clear
echo -e "First example for find:\n"

echo -e "find . -name 'my*'\n"
find . -name 'my*'

pause

echo -e "find . -name \"my*\" -type f\n"
find . -name "my*" -type f

pause

echo -e "find . -name \"my*\" -type f -ls\n"
find . -name "my*" -type f -ls

pause

echo -e "find . -path ./mydir1 -prune -o -type f -name \"my*\" -print\n"
find . -path ./mydir1 -prune -o -type f -name "my*" -print

pause

echo -e "find . \( -name \"*text1*\" -o -name \"*file1*\" \) -type f"
find . \( -name "*text1*" -o -name "*file1*" \) -type f


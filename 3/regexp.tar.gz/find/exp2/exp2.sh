#/bin/bash

function pause()
{
  echo ""
  read -p "Enter to continue"
  echo ""
}
function status()
{
  echo -e "Status of this directory now:\n"
  ls -l *
}

clear
echo -e "Second example for find:\n"
./.restore.sh
echo -e "Status of this directory at beginning of this example:\n"
ls -l *
pause

echo -e "find . -name '*.txt' -exec chmod 644 {} \;\n"
find . -name '*.txt' -exec chmod 644 {} \;
status
pause

echo -e "find . -name \"file1*\" -delete\n"
find . -name "file1*" -delete
status


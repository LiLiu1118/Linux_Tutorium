#!/bin/bash

touch file1.txt file2.txt script.sh
chmod 555 file1.txt
chmod 466 file2.txt
